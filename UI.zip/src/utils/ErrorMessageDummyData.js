export const dummy = [
  {
    id: 1,
    message: "Cemera not responding",
    Timestamp: "1714741513",
  },
  {
    id: 2,
    message: "Front lidar data interuppted",
    Timestamp: "1714741621",
  },
  {
    id: 3,
    message: "Reconnect the display",
    Timestamp: "1714741725",
  },
];
